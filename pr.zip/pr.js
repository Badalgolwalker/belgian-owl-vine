gsap.to("#im", {
    onStart: function() {
      document.querySelector("#im").style.backgroundImage = `url(https://media-cdn.tripadvisor.com/media/photo-s/02/80/94/75/imah-seniman-in-morning.jpg)`
    },
    scrollTrigger: {
      scroller: "body",
      markers: true,
      trigger: "#page",
      start: "top top",
      end: "bottom top",
      scrub: 3
    }
  });
  gsap.to("#im", {
    onStart: function() {
      document.querySelector("#im").style.backgroundImage = `url(https://i.pinimg.com/originals/5c/f1/fa/5cf1faf9e9982c49be2a96c173c96793.jpg)`
    },
    scrollTrigger: {
      scroller: "body",
      markers: true,
      trigger: "#page1",
      start: "top top",
      end: "bottom top",
      scrub: 3,
      pin:true
      
    }
  });